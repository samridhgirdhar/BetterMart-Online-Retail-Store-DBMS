-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: bettermart
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `cart_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int DEFAULT NULL,
  `item_count` int DEFAULT '0',
  `total_cost` int DEFAULT '0',
  PRIMARY KEY (`cart_id`),
  KEY `cart_fk_customer_id` (`customer_id`),
  CONSTRAINT `cart_fk_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (1,NULL,8,3886),(2,NULL,8,5566),(3,NULL,32,203),(4,NULL,35,3334),(5,NULL,17,3426),(6,NULL,45,5508),(7,NULL,23,7498),(8,NULL,9,7484),(9,NULL,76,946),(10,NULL,22,9053),(11,NULL,1,7970),(12,NULL,45,9166),(13,NULL,77,663),(14,NULL,33,555),(15,NULL,47,142),(16,NULL,57,1996),(17,NULL,66,1973),(18,NULL,35,7739),(19,NULL,62,3707),(20,NULL,27,7595),(21,NULL,54,5928),(22,NULL,74,5980),(23,NULL,47,7390),(24,NULL,68,1943),(25,NULL,38,4563),(26,NULL,32,1598),(27,NULL,58,9604),(28,NULL,46,2720),(29,NULL,48,9940),(30,NULL,97,5024),(31,NULL,31,5720),(32,NULL,86,7908),(33,NULL,73,8755),(34,NULL,14,7978),(35,NULL,46,6909),(36,NULL,84,3937),(37,NULL,63,7784),(38,NULL,38,6955),(39,NULL,68,4455),(40,NULL,42,7820),(41,NULL,98,1052),(42,NULL,36,5210),(43,NULL,52,132),(44,NULL,74,692),(45,NULL,76,2762),(46,NULL,83,4808),(47,NULL,88,3843),(48,NULL,70,7546),(49,NULL,41,5717),(50,NULL,8,9445),(51,NULL,84,2250),(52,NULL,48,4918),(53,NULL,96,1172),(54,NULL,85,5574),(55,NULL,37,6877),(56,NULL,87,7232),(57,NULL,49,3681),(58,NULL,26,479),(59,NULL,16,1013),(60,NULL,87,1663),(61,NULL,20,5723),(62,NULL,65,8150),(63,NULL,39,2584),(64,NULL,77,1083),(65,NULL,53,9299),(66,NULL,94,9256),(67,NULL,25,9412),(68,NULL,53,1553),(69,NULL,41,4028),(70,NULL,31,6842),(71,NULL,24,6414),(72,NULL,32,5693),(73,NULL,78,7810),(74,NULL,13,5862),(75,NULL,29,2100),(76,NULL,88,139),(77,NULL,13,1073),(78,NULL,52,1609),(79,NULL,32,4147),(80,NULL,19,4691),(81,NULL,30,568),(82,NULL,84,5999),(83,NULL,72,567),(84,NULL,71,1255),(85,NULL,77,8155),(86,NULL,36,9900),(87,NULL,77,1157),(88,NULL,72,372),(89,NULL,95,5757),(90,NULL,73,4177),(91,NULL,80,4288),(92,NULL,3,6340),(93,NULL,70,1522),(94,NULL,76,919),(95,NULL,24,7035),(96,NULL,76,9593),(97,NULL,70,3562),(98,NULL,67,5008),(99,NULL,40,8778),(100,NULL,46,9952);
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `catregory_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Electronics'),(2,'Appliances'),(3,'Home decor'),(4,'Grooming');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(15) NOT NULL,
  `customer_email` varchar(30) DEFAULT NULL,
  `customer_address` varchar(200) DEFAULT NULL,
  `customer_age` int DEFAULT NULL,
  `customer_number` varchar(10) DEFAULT NULL,
  `customer_paymentDetails` varchar(100) DEFAULT NULL,
  `prev_orders` varchar(10) DEFAULT NULL,
  `customer_fav` varchar(10) DEFAULT NULL,
  `curr_queries` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'ogludor0','amarcham0@angelfire.com','PO Box 74052',56,'9554157501','Fusion Lumsac Jt w Nonaut Sub, Post Appr A Col, Open',NULL,NULL,NULL),(2,'nruncieman1','lielden1@ucla.edu','PO Box 72475',43,'9564536892','Planar Nucl Med Imag of Chest & Neck using Technetium 99m',NULL,NULL,NULL),(3,'ngentner2','cfardell2@businesswire.com','Apt 594',54,'7219204796','Release Left Retinal Vessel, Percutaneous Approach',NULL,NULL,NULL),(4,'nsumers3','crubanenko3@epa.gov','11th Floor',40,'1288826094','Repair Left Tarsal Joint, Percutaneous Endoscopic Approach',NULL,NULL,NULL),(5,'gdrinkhall4','lmcgeachy4@mit.edu','Apt 1195',60,'5082537958','Remove Contracept Dev from Low Extrem Subcu/Fascia, Open',NULL,NULL,NULL),(6,'ogile5','seul5@businesswire.com','Suite 90',30,'6604211724','Revision of Other Device in Pelvic Cavity, Open Approach',NULL,NULL,NULL),(7,'amadill6','eohartnett6@deliciousdays.com','Apt 1109',25,'4264545051','Bypass Left Axillary Artery to Lower Arm Vein, Open Approach',NULL,NULL,NULL),(8,'raldrin7','cfrensch7@theatlantic.com','Room 849',47,'1551816413','Excision of Bladder Neck, Via Opening, Diagn',NULL,NULL,NULL),(9,'fchadwick8','yvarne8@merriam-webster.com','Apt 475',58,'7275732908','Repair Left Kidney Pelvis, Open Approach',NULL,NULL,NULL),(10,'lpardue9','cgentle9@imageshack.us','Suite 43',50,'8558297471','Alteration of Left Upper Leg with Nonaut Sub, Perc Approach',NULL,NULL,NULL),(11,'mwolitera','mguwera@omniture.com','Suite 50',39,'9209148936','Drainage of Liver, Percutaneous Approach',NULL,NULL,NULL),(12,'khubbuckb','lmusgraveb@list-manage.com','Room 1530',36,'2404132334','Replace Ventricular Sept w Zooplastic, Perc Endo',NULL,NULL,NULL),(13,'dghidolic','jminnisc@cdc.gov','Room 122',25,'9239581358','Muscle Performance Assessment of Genitourinary System',NULL,NULL,NULL),(14,'lclaxsond','smahareyd@ft.com','12th Floor',57,'2684443044','Dilate Descend Colon w Intralum Dev, Perc Endo',NULL,NULL,NULL),(15,'jtitheringtone','dparlatte@tinyurl.com','PO Box 3730',46,'3608699475','Supplement Hepatic Vein with Nonaut Sub, Perc Approach',NULL,NULL,NULL),(16,'imossbeef','abercerosf@earthlink.net','Apt 1761',54,'1035665792','Beam Radiation of Chest Wall using Photons 1 - 10 MeV',NULL,NULL,NULL),(17,'mbonhommeg','ggawneg@fc2.com','Suite 41',27,'2024501882','Drainage of Gallbladder, Percutaneous Approach, Diagnostic',NULL,NULL,NULL),(18,'nglisonh','bparffreyh@icq.com','17th Floor',26,'1828430441','CT Scan Bi Parotid Gland w H Osm Contrast, Unenh, Enhance',NULL,NULL,NULL),(19,'aloweni','ocapellei@typepad.com','Suite 81',53,'1343414656','Replacement of Bladder Neck with Autol Sub, Endo',NULL,NULL,NULL),(20,'pmccoughanj','dounsworthj@flickr.com','PO Box 87062',53,'2281462298','Drainage of Right Frontal Bone, Percutaneous Approach, Diagn',NULL,NULL,NULL),(21,'dselbiek','crouthamk@ibm.com','9th Floor',36,'8534602952','Fluoroscopy Bi Jugular Vein w H Osm Contrast, Guidance',NULL,NULL,NULL),(22,'ccrinkleyl','abernthl@auda.org.au','14th Floor',44,'7175157595','Revision of Intraluminal Device in Stomach, Extern Approach',NULL,NULL,NULL),(23,'rottosenm','bmcalinionm@miitbeian.gov.cn','Room 1091',22,'4036601738','Supplement Left Vertebral Vein with Autol Sub, Perc Approach',NULL,NULL,NULL),(24,'cbrenstonn','mnivenn@technorati.com','PO Box 94333',52,'3949280611','Reposition Right Common Iliac Artery, Perc Endo Approach',NULL,NULL,NULL),(25,'pbasketto','nreyo@marriott.com','9th Floor',44,'9889557887','Excision of Right Lower Lung Lobe, Endo',NULL,NULL,NULL),(26,'thaggarthp','bridpathp@nsw.gov.au','15th Floor',29,'8454131998','Bypass Bilateral Vas Deferens to R Vas Def, Open Approach',NULL,NULL,NULL),(27,'btrevesq','rjarlmannq@jigsy.com','Suite 76',57,'8236299716','Occlusion of Colic Vein with Intralum Dev, Open Approach',NULL,NULL,NULL),(28,'cdanielkiewiczr','lbasilior@mail.ru','PO Box 24933',60,'7708714545','Repair Bladder, Percutaneous Endoscopic Approach',NULL,NULL,NULL),(30,'wgreschket','hgittingst@dailymail.co.uk','PO Box 47865',58,'8387329569','Plain Radiography of Right Renal Vein using H Osm Contrast',NULL,NULL,NULL),(31,'mgertzu','kgausonu@intel.com','Apt 1761',25,'9094372693','Dilate of R Fem Art with Drug-elut Intra, Perc Endo Approach',NULL,NULL,NULL),(32,'swarykv','holletv@meetup.com','Suite 2',41,'7875042512','Revision of Nonaut Sub in L Ear, Extern Approach',NULL,NULL,NULL),(33,'bhoundsomw','chumerstonew@altervista.org','9th Floor',46,'3699868709','Extraction of Right Auditory Ossicle, Open Approach',NULL,NULL,NULL),(34,'bhobbertx','msivillsx@jiathis.com','PO Box 45417',44,'6092427150','Revision of Neuro Lead in Azygos Vein, Open Approach',NULL,NULL,NULL),(35,'cpaulmanny','lredemiley@wikipedia.org','PO Box 21518',32,'8089968002','Removal of Synth Sub from Up Muscle, Open Approach',NULL,NULL,NULL),(36,'rwhitehornz','ttarbardz@nhs.uk','Apt 1313',36,'2179755376','Revision of Synth Sub in Low Back, Extern Approach',NULL,NULL,NULL),(37,'dninotti10','cshortt10@mapquest.com','Room 1299',29,'8335332895','Remove Infusion Dev from Prostate/Seminal Ves, Open',NULL,NULL,NULL),(38,'wbuchanan11','satherton11@squarespace.com','Apt 274',40,'2709412634','Excision of Right Lower Femur, Perc Endo Approach',NULL,NULL,NULL),(39,'ajambrozek12','mlackney12@phpbb.com','15th Floor',38,'5896059232','MRI of R Toe using Oth Contrast, Unenh, Enhance',NULL,NULL,NULL),(40,'cmears13','hstangoe13@reverbnation.com','1st Floor',34,'8094636551','Repair Right Submaxillary Gland, Percutaneous Approach',NULL,NULL,NULL),(41,'sjeste14','medmunds14@mail.ru','9th Floor',23,'2103662834','Excision of Right Sphenoid Sinus, Open Approach, Diagnostic',NULL,NULL,NULL),(42,'lworsham15','mdanhel15@guardian.co.uk','Room 480',48,'1328162595','Drainage of Right Hand Artery, Open Approach',NULL,NULL,NULL),(43,'sgrollmann16','cwrettum16@abc.net.au','Suite 51',58,'9918338627','Bypass Abd Aorta to Celiac Art w Nonaut Sub, Open',NULL,NULL,NULL),(44,'brandles17','ljaggard17@cmu.edu','14th Floor',35,'8942779269','Excision of Bladder, Open Approach',NULL,NULL,NULL),(45,'vbruckner18','kjadczak18@fda.gov','Apt 92',52,'2603467752','LDR Brachytherapy of Brain Stem using Iridium 192',NULL,NULL,NULL),(46,'mmcilwraith19','mshapiro19@g.co','11th Floor',30,'2558892752','Replacement of R Ext Carotid with Autol Sub, Open Approach',NULL,NULL,NULL),(47,'jstones1a','bwaldera1a@issuu.com','PO Box 1486',21,'9113978101','Dilation of Left Foot Vein, Percutaneous Endoscopic Approach',NULL,NULL,NULL),(48,'ltomaino1b','gfilkov1b@princeton.edu','Room 1105',49,'7915318390','Drainage of Minor Salivary Gland, Perc Approach, Diagn',NULL,NULL,NULL),(49,'mmarchiso1c','hrattenberie1c@accuweather.com','Suite 72',30,'8475540969','Drainage of Right Tarsal, Percutaneous Approach',NULL,NULL,NULL),(50,'ichampneys1d','emadsen1d@github.com','Room 1578',24,'1507188836','Drainage of Right Large Intestine, Endo',NULL,NULL,NULL),(51,'mguerrieri1e','pkiezler1e@huffingtonpost.com','14th Floor',49,'9963911437','Excision of Right Thyroid Artery, Perc Endo Approach',NULL,NULL,NULL),(52,'ahatcliffe1f','cseldner1f@microsoft.com','8th Floor',36,'2717604694','Insertion of Monitoring Device into Up Vein, Perc Approach',NULL,NULL,NULL),(53,'pspreag1g','mcomizzoli1g@bloglovin.com','PO Box 65095',23,'1805044840','Supplement L Post Tib Art with Autol Sub, Perc Approach',NULL,NULL,NULL),(54,'mbudding1h','fsnowden1h@blinklist.com','10th Floor',25,'7608541616','Removal of Spacer from R Toe Phalanx Jt, Perc Approach',NULL,NULL,NULL),(55,'jgrabeham1i','mbachanski1i@yandex.ru','1st Floor',54,'9993864341','Revision of Infusion Dev in Coccygeal Jt, Perc Endo Approach',NULL,NULL,NULL),(56,'spresidey1j','hbeeckx1j@exblog.jp','2nd Floor',43,'2273355399','Repair Basal Ganglia, Open Approach',NULL,NULL,NULL),(57,'sidill1k','eforrington1k@php.net','Apt 1336',58,'4897026701','Fluoroscopy Intercos/Bronc A w H Osm Contrast, Laser Intraop',NULL,NULL,NULL),(58,'schetter1l','tdegrey1l@nhs.uk','Apt 1386',55,'9265992384','Drainage of L Brach Vein with Drain Dev, Perc Endo Approach',NULL,NULL,NULL),(59,'dmolian1m','gbunyan1m@freewebs.com','PO Box 50057',58,'5812853689','Replacement of R Hip Jt with Ceramic, Cement, Open Approach',NULL,NULL,NULL),(60,'faskey1n','sesche1n@senate.gov','Suite 92',21,'3144406617','Bypass L Pulm Art from Subclav w Nonaut Sub, Open',NULL,NULL,NULL),(61,'lfeldman1o','tharrigan1o@surveymonkey.com','Suite 93',37,'9799686265','Drainage of Coccygeal Joint, Perc Endo Approach, Diagn',NULL,NULL,NULL),(62,'zcharlwood1p','tgennings1p@go.com','PO Box 56792',36,'4794197839','Bypass R Fallopian Tube to L Fallop w Autol Sub, Perc Endo',NULL,NULL,NULL),(63,'lwabey1q','hgheorghescu1q@is.gd','Room 539',20,'7661931296','Dilate Celiac Art, Bifurc, w 3 Intralum Dev, Perc Endo',NULL,NULL,NULL),(64,'cchallenor1r','spippard1r@smugmug.com','Apt 1419',53,'4833183640','Bypass 3 Cor Art from R Int Mammary, Open Approach',NULL,NULL,NULL),(65,'ebettenson1s','vfaye1s@census.gov','Room 1127',55,'4769084772','Release Left Brachial Artery, Open Approach',NULL,NULL,NULL),(66,'ntomasian1t','jhearty1t@newyorker.com','1st Floor',37,'8898291909','Remove Synth Sub from L Knee Jt, Femoral, Perc Endo',NULL,NULL,NULL),(67,'clodewick1u','zfeathers1u@wikia.com','PO Box 36233',45,'6991290214','Drainage of Basal Ganglia, Perc Endo Approach, Diagn',NULL,NULL,NULL),(68,'twhardley1v','santyshev1v@about.com','PO Box 70594',25,'1794418282','Bypass Mid Esophag to Jejunum w Nonaut Sub, Perc Endo',NULL,NULL,NULL),(69,'elazell1w','gjeannard1w@marriott.com','Apt 1068',57,'3019016281','Dilate 2 Cor Art, Bifurc, w 4 Drug-elut, Perc Endo',NULL,NULL,NULL),(70,'zstoneman1x','dlamping1x@bigcartel.com','Suite 93',41,'7172830144','Drainage of Lumbar Sympathetic Nerve, Percutaneous Approach',NULL,NULL,NULL),(71,'rpyne1y','etremberth1y@amazonaws.com','Apt 1025',57,'1317946538','Insert Mult Array Stim Gen in Abd Subcu/Fascia, Open',NULL,NULL,NULL),(72,'dklausewitz1z','mreolfi1z@tiny.cc','Apt 740',23,'5522816337','Revision of Intralum Dev in Tracheobronc Tree, Via Opening',NULL,NULL,NULL),(73,'adoornbos20','pkempe20@oracle.com','Apt 592',44,'3025743264','Bypass Cecum to Rectum, Open Approach',NULL,NULL,NULL),(74,'cmcginlay21','xbrewitt21@amazon.co.jp','PO Box 83392',45,'6073763747','Replacement of Sup Mesent Vein with Synth Sub, Open Approach',NULL,NULL,NULL),(75,'ejosham22','goldroyde22@seesaa.net','PO Box 45191',53,'8449612076','Drainage of Basal Ganglia, Percutaneous Endoscopic Approach',NULL,NULL,NULL),(76,'amuckloe23','csquibbs23@prnewswire.com','Room 1478',39,'9484722617','Excision of Bilateral Fallopian Tubes, Perc Approach, Diagn',NULL,NULL,NULL),(77,'efilippello24','schisnall24@spiegel.de','Apt 1233',57,'1581695010','Remove Radioact Elem from Prostate/Seminal Ves, Perc',NULL,NULL,NULL),(78,'tscrivinor25','esambeck25@indiegogo.com','PO Box 32651',33,'8845691397','Destruction of Left Upper Femur, Perc Endo Approach',NULL,NULL,NULL),(79,'rprandi26','shammer26@cafepress.com','13th Floor',25,'1058603318','Dilation of Face Artery, Percutaneous Endoscopic Approach',NULL,NULL,NULL),(80,'hcurzey27','toblein27@a8.net','Apt 1507',26,'9485945348','Insertion of Int Fix into R Occipital Bone, Open Approach',NULL,NULL,NULL),(81,'moroan28','rflindall28@sun.com','10th Floor',38,'6982864161','Beam Radiation of Chest using Neutron Capture',NULL,NULL,NULL),(82,'gbanton29','otinkler29@netlog.com','Apt 361',41,'3842283587','Chiropractic Manipulation Thoracic Region, Indirect Visceral',NULL,NULL,NULL),(83,'pdorian2a','csiemens2a@noaa.gov','Room 1164',38,'4515781764','Alteration of L Up Extrem with Synth Sub, Perc Endo Approach',NULL,NULL,NULL),(84,'cdominique2b','sbrounsell2b@uiuc.edu','Room 642',53,'1444889692','Insert Infusion Dev in L Femoral Region, Perc Endo',NULL,NULL,NULL),(85,'lbuxy2c','msearl2c@indiegogo.com','Apt 856',51,'3492469548','Drainage of Right Inguinal Region, Open Approach, Diagnostic',NULL,NULL,NULL),(86,'lmayall2d','gpatnelli2d@cnet.com','Suite 70',50,'6778182162','Supplement Left Toe Phalanx with Autol Sub, Open Approach',NULL,NULL,NULL),(87,'agatus2e','vbyram2e@edublogs.org','16th Floor',39,'7439930326','Revision of Autol Sub in Fallopian Tube, Endo',NULL,NULL,NULL),(88,'mlester2f','sescott2f@berkeley.edu','Apt 1524',41,'5071753100','Remove Infusion Dev from L Shoulder Jt, Perc Endo',NULL,NULL,NULL),(89,'gmcgurk2g','kcoolson2g@geocities.jp','PO Box 3846',27,'2028196561','Beam Radiation of Hard Palate using Photons <1 MeV',NULL,NULL,NULL),(90,'gfrost2h','nlocks2h@mediafire.com','Suite 18',37,'5434000607','Restriction of Small Intest with Intralum Dev, Via Opening',NULL,NULL,NULL),(91,'pdengate2i','cbudgen2i@timesonline.co.uk','PO Box 26183',49,'7403733818','Dilate R Int Mamm Art, Bifurc, w 4 Drug-elut, Open',NULL,NULL,NULL),(92,'astalf2j','fkells2j@princeton.edu','Apt 738',49,'5298714370','Removal of Synth Sub from Pancreat Duct, Perc Approach',NULL,NULL,NULL),(93,'tnattriss2k','pdempster2k@examiner.com','5th Floor',55,'1379996508','Drainage of Right Lesser Saphenous Vein, Perc Approach',NULL,NULL,NULL),(94,'cdodd2l','bawmack2l@spiegel.de','Suite 62',20,'9537067942','Removal of Autol Sub from L Toe Phalanx, Open Approach',NULL,NULL,NULL),(95,'mraynham2m','edarwin2m@telegraph.co.uk','6th Floor',23,'5541249215','Revision of Drainage Device in C-thor Disc, Extern Approach',NULL,NULL,NULL),(96,'gtaudevin2n','rfolbigg2n@google.pl','PO Box 39389',28,'2117087179','Drainage of Left Lower Arm, Percutaneous Approach, Diagn',NULL,NULL,NULL),(97,'lsatterly2o','nsanpher2o@123-reg.co.uk','Apt 793',60,'4055279273','Revise of Autol Sub in Up Extrem Subcu/Fascia, Open Approach',NULL,NULL,NULL),(98,'kmillam2p','alapsley2p@elpais.com','Suite 66',45,'6002233268','Resection of Left Upper Arm Muscle, Perc Endo Approach',NULL,NULL,NULL),(99,'mlambden2q','vpampling2q@ft.com','5th Floor',53,'7267789363','Bypass L Atrium to R Pulm Vn with Autol Art, Open Approach',NULL,NULL,NULL),(100,'vtainton2r','gsidwell2r@fotki.com','Room 815',28,'2123485631','Change Drainage Device in Chest Wall, External Approach',NULL,NULL,NULL);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_partner`
--

DROP TABLE IF EXISTS `delivery_partner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_partner` (
  `delivery_partner_id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(20) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `order_id` int DEFAULT NULL,
  `retailer_id` int DEFAULT NULL,
  PRIMARY KEY (`delivery_partner_id`),
  KEY `fk_delivery_partner_id` (`order_id`),
  KEY `fk_retailer_id` (`retailer_id`),
  CONSTRAINT `fk_delivery_partner_id` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  CONSTRAINT `fk_retailer_id` FOREIGN KEY (`retailer_id`) REFERENCES `retailer` (`retailer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_partner`
--

LOCK TABLES `delivery_partner` WRITE;
/*!40000 ALTER TABLE `delivery_partner` DISABLE KEYS */;
INSERT INTO `delivery_partner` VALUES (1,'Very small','At capacity',NULL,NULL),(2,'Small','Available',NULL,NULL),(3,'Very small','Unavailable',NULL,NULL),(4,'Very small','Available',NULL,NULL),(5,'Very small','At capacity',NULL,NULL),(6,'Small','At capacity',NULL,NULL),(7,'Small','At capacity',NULL,NULL),(8,'Large','Unavailable',NULL,NULL),(9,'Very small','Available',NULL,NULL),(10,'Small','Unavailable',NULL,NULL),(11,'Very small','At capacity',NULL,NULL),(12,'Small','Unavailable',NULL,NULL),(13,'Small','Available',NULL,NULL),(14,'Very small','Available',NULL,NULL),(15,'Large','Unavailable',NULL,NULL),(16,'Small','Unavailable',NULL,NULL),(17,'Small','Unavailable',NULL,NULL),(18,'Very small','At capacity',NULL,NULL),(19,'Very small','Unavailable',NULL,NULL),(20,'Small','Unavailable',NULL,NULL),(21,'Very small','Unavailable',NULL,NULL),(22,'Very small','Available',NULL,NULL),(23,'Small','At capacity',NULL,NULL),(24,'Very small','Unavailable',NULL,NULL),(25,'Very small','Unavailable',NULL,NULL),(26,'Small','Available',NULL,NULL),(27,'Very small','Unavailable',NULL,NULL),(28,'Very small','At capacity',NULL,NULL),(29,'Small','Unavailable',NULL,NULL),(30,'Small','Unavailable',NULL,NULL),(31,'Very small','Available',NULL,NULL),(32,'Large','Unavailable',NULL,NULL),(33,'Very small','Available',NULL,NULL),(34,'Very small','Available',NULL,NULL),(35,'Very small','Available',NULL,NULL),(36,'Large','Available',NULL,NULL),(37,'Large','At capacity',NULL,NULL),(38,'Small','Available',NULL,NULL),(39,'Very small','At capacity',NULL,NULL),(40,'Very small','Available',NULL,NULL),(41,'Large','At capacity',NULL,NULL),(42,'Small','At capacity',NULL,NULL),(43,'Large','At capacity',NULL,NULL),(44,'Small','Unavailable',NULL,NULL),(45,'Very small','At capacity',NULL,NULL),(46,'Small','Available',NULL,NULL),(47,'Small','At capacity',NULL,NULL),(48,'Very small','Unavailable',NULL,NULL),(49,'Small','Unavailable',NULL,NULL),(50,'Large','At capacity',NULL,NULL),(51,'Very small','Available',NULL,NULL),(52,'Large','Unavailable',NULL,NULL),(53,'Small','At capacity',NULL,NULL),(54,'Very small','Unavailable',NULL,NULL),(55,'Small','Available',NULL,NULL),(56,'Very small','Available',NULL,NULL),(57,'Large','Unavailable',NULL,NULL),(58,'Small','Available',NULL,NULL),(59,'Small','Available',NULL,NULL),(60,'Small','At capacity',NULL,NULL),(61,'Small','At capacity',NULL,NULL),(62,'Small','Unavailable',NULL,NULL),(63,'Very small','Unavailable',NULL,NULL),(64,'Very small','Unavailable',NULL,NULL),(65,'Large','Available',NULL,NULL),(66,'Small','Unavailable',NULL,NULL),(67,'Very small','Available',NULL,NULL),(68,'Large','Unavailable',NULL,NULL),(69,'Large','Available',NULL,NULL),(70,'Small','Available',NULL,NULL),(71,'Small','Unavailable',NULL,NULL),(72,'Small','Unavailable',NULL,NULL),(73,'Small','At capacity',NULL,NULL),(74,'Very small','Unavailable',NULL,NULL),(75,'Large','At capacity',NULL,NULL),(76,'Small','Available',NULL,NULL),(77,'Small','Unavailable',NULL,NULL),(78,'Very small','At capacity',NULL,NULL),(79,'Small','Unavailable',NULL,NULL),(80,'Large','At capacity',NULL,NULL),(81,'Large','At capacity',NULL,NULL),(82,'Large','At capacity',NULL,NULL),(83,'Small','At capacity',NULL,NULL),(84,'Large','At capacity',NULL,NULL),(85,'Small','Available',NULL,NULL),(86,'Large','At capacity',NULL,NULL),(87,'Small','At capacity',NULL,NULL),(88,'Large','At capacity',NULL,NULL),(89,'Small','Available',NULL,NULL),(90,'Large','At capacity',NULL,NULL),(91,'Large','Unavailable',NULL,NULL),(92,'Large','Unavailable',NULL,NULL),(93,'Small','Available',NULL,NULL),(94,'Small','Unavailable',NULL,NULL),(95,'Small','Unavailable',NULL,NULL),(96,'Very small','Available',NULL,NULL),(97,'Small','At capacity',NULL,NULL),(98,'Very small','At capacity',NULL,NULL),(99,'Small','At capacity',NULL,NULL),(100,'Very small','Available',NULL,NULL);
/*!40000 ALTER TABLE `delivery_partner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer`
--

DROP TABLE IF EXISTS `offer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offer` (
  `offer_id` int NOT NULL AUTO_INCREMENT,
  `discount_percentage` int DEFAULT '0',
  `min_amount` int DEFAULT '0',
  `max_amount` int DEFAULT '0',
  `validity` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`offer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer`
--

LOCK TABLES `offer` WRITE;
/*!40000 ALTER TABLE `offer` DISABLE KEYS */;
INSERT INTO `offer` VALUES (1,76,880,528492,'125'),(2,43,257,14117,'156'),(3,17,7542,326725,'249'),(4,66,6969,453919,'237'),(5,60,9659,130120,'235'),(6,73,9861,998514,'246'),(7,37,8880,970379,'166'),(8,9,473,427604,'352'),(9,64,5949,527659,'278'),(10,30,4252,495673,'205'),(11,25,8393,302578,'184'),(12,99,6279,866751,'109'),(13,30,9816,381495,'331'),(14,64,4172,33901,'327'),(15,6,5626,350780,'354'),(16,72,1253,96330,'300'),(17,54,9337,521999,'185'),(18,27,4725,350852,'115'),(19,87,4502,197043,'309'),(20,17,8046,290678,'203'),(21,57,5656,650468,'271'),(22,78,3064,537263,'266'),(23,24,6227,828376,'357'),(24,5,1925,628369,'143'),(25,26,6257,928020,'186'),(26,66,6339,129231,'340'),(27,43,2652,922005,'296'),(28,49,9528,482059,'217'),(29,13,6982,761398,'283'),(30,23,4518,505580,'206'),(31,41,3474,766733,'267'),(32,78,4960,122518,'101'),(33,77,9078,845523,'164'),(34,87,9838,802369,'273'),(35,29,3492,455149,'138'),(36,85,9338,203898,'271'),(37,65,2750,905165,'169'),(38,2,4255,137444,'248'),(39,89,554,420550,'346'),(40,54,1447,109301,'195'),(41,56,140,998908,'114'),(42,89,5978,921605,'340'),(43,48,1368,211979,'268'),(44,79,6609,594354,'352'),(45,35,124,691060,'289'),(46,60,7155,538655,'304'),(47,81,3164,498971,'101'),(48,34,9238,704547,'134'),(49,96,4613,368053,'238'),(50,69,3138,805216,'236'),(51,53,1887,352969,'118'),(52,22,9677,154506,'149'),(53,30,6153,405551,'237'),(54,18,2860,855327,'235'),(55,95,8609,450580,'113'),(56,90,1580,777549,'200'),(57,94,4699,350110,'201'),(58,25,2075,467699,'198'),(59,25,5339,265367,'360'),(60,50,8855,655295,'211'),(61,20,1812,357821,'342'),(62,94,943,247207,'312'),(63,70,3277,675741,'184'),(64,36,7272,956042,'204'),(65,68,2074,716833,'188'),(66,94,6177,342944,'245'),(67,29,676,649279,'189'),(68,4,5517,54774,'178'),(69,60,2026,971553,'233'),(70,7,194,870504,'216'),(71,50,5176,229424,'174'),(72,2,6152,707428,'272'),(73,19,5387,200581,'320'),(74,35,9739,265077,'125'),(75,16,5998,201618,'123'),(76,16,6176,282756,'115'),(77,19,3952,276126,'226'),(78,68,5866,799784,'353'),(79,9,3958,727590,'281'),(80,79,4373,523998,'345'),(81,39,3493,178845,'157'),(82,74,2697,288325,'218'),(83,29,1246,877820,'284'),(84,100,150,885332,'257'),(85,70,420,279663,'131'),(86,96,732,335783,'277'),(87,95,5047,11400,'310'),(88,91,1373,353033,'204'),(89,17,5784,120666,'275'),(90,100,647,788838,'130'),(91,34,5539,752608,'141'),(92,64,7573,976741,'358'),(93,59,9651,72464,'188'),(94,57,3587,305807,'231'),(95,25,3118,533328,'337'),(96,2,9989,511740,'334'),(97,11,5569,489049,'106'),(98,52,4804,855913,'361'),(99,37,9317,768984,'356'),(100,23,6051,822223,'209');
/*!40000 ALTER TABLE `offer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `order_date` int DEFAULT NULL,
  `delivery_partner_id` int DEFAULT '0',
  `customer_id` int DEFAULT NULL,
  `retailer_id` int DEFAULT NULL,
  `payment_id` int DEFAULT NULL,
  `time_date` varchar(30) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `fk_customer_id` (`customer_id`),
  KEY `delivery_partner_id` (`delivery_partner_id`),
  KEY `retailer_id` (`retailer_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `fk_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`delivery_partner_id`) REFERENCES `delivery_partner` (`delivery_partner_id`),
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`retailer_id`) REFERENCES `retailer` (`retailer_id`),
  CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `mode` varchar(20) DEFAULT NULL,
  `details` varchar(100) DEFAULT NULL,
  `order_id` int DEFAULT NULL,
  `customer_id` int DEFAULT NULL,
  `time_date` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `fk_order_id` (`order_id`),
  KEY `payment_fk_customer_id` (`customer_id`),
  CONSTRAINT `fk_order_id` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  CONSTRAINT `payment_fk_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,'Netbanking','Part dacryoadenect NEC',NULL,NULL,'2022-07-28 15:47:08'),(2,'Netbanking','Angiocardiography NOS',NULL,NULL,'2022-09-03 16:07:14'),(3,'Netbanking','Micro exam-nervous NEC',NULL,NULL,'2022-03-09 05:38:09'),(4,'COD','Lac passage manip NEC',NULL,NULL,'2022-08-21 16:41:11'),(5,'Debit Card','Injec air-periton cavity',NULL,NULL,'2022-07-24 16:11:42'),(6,'Netbanking','Insert pseudophakos NOS',NULL,NULL,'2023-02-08 07:45:57'),(7,'Debit Card','Other repair of ankle',NULL,NULL,'2022-07-10 16:49:29'),(8,'COD','Oth lo vision aid dispen',NULL,NULL,'2022-10-01 05:46:23'),(9,'Credit Card','C & s NEC',NULL,NULL,'2022-09-26 18:05:56'),(10,'Netbanking','Ext carot art lig-epist',NULL,NULL,'2022-07-03 22:51:48'),(11,'Credit Card','Cath base invasv ep test',NULL,NULL,'2022-11-13 02:19:46'),(12,'Credit Card','Incision of chest wall',NULL,NULL,'2022-06-20 05:49:38'),(13,'Credit Card','Amputation through hand',NULL,NULL,'2022-08-26 05:14:43'),(14,'COD','Culture-female genital',NULL,NULL,'2023-01-11 23:35:01'),(15,'COD','Spinal x-ray NEC',NULL,NULL,'2022-04-28 21:47:33'),(16,'Credit Card','Insert endotracheal tube',NULL,NULL,'2023-01-15 21:57:27'),(17,'Netbanking','Urethrotomy',NULL,NULL,'2022-10-31 12:33:28'),(18,'COD','Dilation of rectum',NULL,NULL,'2022-08-02 22:41:03'),(19,'COD','Endotracheal bronchogram',NULL,NULL,'2022-08-30 14:31:53'),(20,'Credit Card','Cl fx reduc-metacar/car',NULL,NULL,'2022-12-09 12:55:27'),(21,'Credit Card','Coron vess aneurysm rep',NULL,NULL,'2022-10-07 23:24:33'),(22,'Netbanking','Aortocor bypas-2 cor art',NULL,NULL,'2023-01-05 17:25:11'),(23,'Netbanking','Contrast x-ray of orbit',NULL,NULL,'2022-04-02 16:32:35'),(24,'Credit Card','Spermatic cord incision',NULL,NULL,'2022-05-27 23:30:16'),(25,'Debit Card','Parasitology-endocrine',NULL,NULL,'2022-10-13 19:26:44'),(26,'COD','Lap part cholecystectomy',NULL,NULL,'2022-06-12 14:18:48'),(27,'Debit Card','Incis perianal abscess',NULL,NULL,'2022-06-15 12:01:07'),(28,'COD','Arthrodesis of hip',NULL,NULL,'2022-08-17 08:16:01'),(29,'Debit Card','Intestinal fixation NOS',NULL,NULL,'2022-07-02 01:26:26'),(30,'COD','Vagin/cul-de-sac dx NEC',NULL,NULL,'2022-05-20 21:48:01'),(31,'Debit Card','Tetanus toxoid administ',NULL,NULL,'2022-09-09 15:05:18'),(32,'Netbanking','Unilat radical mastectom',NULL,NULL,'2022-12-14 10:44:52'),(33,'COD','Opn bx larynx or trachea',NULL,NULL,'2022-10-17 06:37:29'),(34,'Credit Card','Reattachment NEC',NULL,NULL,'2022-07-05 13:27:08'),(35,'Netbanking','Excis/destr les phar NEC',NULL,NULL,'2022-04-18 11:45:50'),(36,'COD','Scleral buckle w implant',NULL,NULL,'2022-04-09 19:04:32'),(37,'Credit Card','Repl joint of foot, toe',NULL,NULL,'2022-04-25 15:48:47'),(38,'COD','Ovarian aspirat biopsy',NULL,NULL,'2022-09-18 03:44:23'),(39,'Netbanking','Plast op hand w grft NEC',NULL,NULL,'2022-10-30 05:28:11'),(40,'Credit Card','Hemorrhage control NOS',NULL,NULL,'2022-10-10 15:43:56'),(41,'Credit Card','Seminal vesicle excision',NULL,NULL,'2023-01-11 07:21:48'),(42,'COD','Oxygen enrichment NEC',NULL,NULL,'2022-07-24 05:58:17'),(43,'Credit Card','Excision of uvula',NULL,NULL,'2022-06-09 18:43:07'),(44,'COD','Bronchial repair NEC',NULL,NULL,'2023-01-06 15:00:44'),(45,'Credit Card','Occlus intracran ves NEC',NULL,NULL,'2022-04-12 03:18:43'),(46,'Credit Card','Bladder neck dilation',NULL,NULL,'2022-07-18 13:58:36'),(47,'Netbanking','Blood vessel dx proc NEC',NULL,NULL,'2022-12-22 17:56:07'),(48,'Credit Card','Laparotomy NEC',NULL,NULL,'2022-10-02 03:55:24'),(49,'COD','Other local destruc skin',NULL,NULL,'2022-08-28 03:58:58'),(50,'COD','Rad node dissection NOS',NULL,NULL,'2022-03-12 10:36:12'),(51,'Debit Card','Puncture of spleen',NULL,NULL,'2022-05-23 12:59:28'),(52,'COD','Removal FB from arm',NULL,NULL,'2023-01-05 07:49:27'),(53,'Credit Card','Anesth inject-spin canal',NULL,NULL,'2022-12-27 08:59:25'),(54,'COD','Replace wound pack/drain',NULL,NULL,'2022-03-15 22:19:33'),(55,'Debit Card','Remove orbital implant',NULL,NULL,'2022-06-27 11:31:06'),(56,'Netbanking','Local lg bowel perfusion',NULL,NULL,'2022-04-14 21:53:50'),(57,'Debit Card','Pros rep ventric def-opn',NULL,NULL,'2022-09-22 23:18:47'),(58,'Debit Card','Rad node dissection NOS',NULL,NULL,'2022-12-09 10:19:47'),(59,'Netbanking','Excise tib/fib for graft',NULL,NULL,'2022-04-15 00:25:44'),(60,'Netbanking','Total parathyroidectomy',NULL,NULL,'2022-11-26 22:10:25'),(61,'COD','Scrotum & tunica op NEC',NULL,NULL,'2022-03-04 19:58:58'),(62,'Netbanking','Cl reduc disloc-elbow',NULL,NULL,'2023-01-08 12:19:08'),(63,'Debit Card','Implant CCM pulse genrtr',NULL,NULL,'2022-04-25 22:54:52'),(64,'Credit Card','Cervical les cryotherapy',NULL,NULL,'2022-04-01 21:27:30'),(65,'Credit Card','Op bi dr/in ig hr-gr NEC',NULL,NULL,'2022-06-27 03:59:36'),(66,'Netbanking','Humerus wedge osteotomy',NULL,NULL,'2022-12-02 15:09:43'),(67,'Credit Card','Venous cutdown',NULL,NULL,'2022-07-14 11:30:44'),(68,'Debit Card','Eye examination NOS',NULL,NULL,'2022-03-05 15:30:53'),(69,'Credit Card','Hemorrhoid procedure NEC',NULL,NULL,'2022-09-30 16:58:33'),(70,'Debit Card','Hemorr contrl post T & A',NULL,NULL,'2022-08-14 06:12:30'),(71,'Credit Card','Creat esophagastr sphinc',NULL,NULL,'2022-11-21 13:39:51'),(72,'COD','Abdominal endarterectomy',NULL,NULL,'2022-06-21 05:36:46'),(73,'COD','Pancreat transplant NOS',NULL,NULL,'2022-12-07 07:53:57'),(74,'Netbanking','External ear incis NEC',NULL,NULL,'2022-08-12 15:56:59'),(75,'Debit Card','Allo hem stem ct w purg',NULL,NULL,'2023-02-05 13:27:07'),(76,'Netbanking','Clin vestibul funct test',NULL,NULL,'2022-09-11 18:38:10'),(77,'Netbanking','Incision of penis',NULL,NULL,'2022-05-02 05:30:03'),(78,'Debit Card','Opn dir ing hern-gft NEC',NULL,NULL,'2022-02-27 20:21:36'),(79,'COD','Reattachment NEC',NULL,NULL,'2022-03-26 01:28:39'),(80,'COD','Uterine art emb w/o coil',NULL,NULL,'2022-03-03 21:05:59'),(81,'Debit Card','Ther ult head & neck ves',NULL,NULL,'2022-07-21 10:38:45'),(82,'COD','Other brain dx procedure',NULL,NULL,'2023-01-18 22:30:22'),(83,'Debit Card','Hand muscle reattachment',NULL,NULL,'2022-05-22 13:04:30'),(84,'Debit Card','Cl reduc disloc-hip',NULL,NULL,'2022-05-24 16:24:25'),(85,'Debit Card','Bicycle ergometer test',NULL,NULL,'2022-11-10 09:46:30'),(86,'Netbanking','Applic ext fix dev NOS',NULL,NULL,'2022-03-10 11:38:51'),(87,'COD','Remov intralum mouth FB',NULL,NULL,'2022-05-31 02:23:07'),(88,'Debit Card','Scrotum & tunica i & d',NULL,NULL,'2022-05-10 02:12:17'),(89,'Credit Card','Head & neck endarter NEC',NULL,NULL,'2022-06-29 02:37:21'),(90,'Debit Card','Achillotenotomy',NULL,NULL,'2022-07-28 11:41:06'),(91,'Credit Card','Attach pedicle graft NEC',NULL,NULL,'2022-08-04 00:54:37'),(92,'Debit Card','Lap part cholecystectomy',NULL,NULL,'2022-04-15 22:45:19'),(93,'Netbanking','Bone mineral density',NULL,NULL,'2022-12-07 20:48:47'),(94,'Netbanking','Thyroid vessel ligation',NULL,NULL,'2022-04-24 01:57:41'),(95,'Debit Card','Thermography NEC',NULL,NULL,'2023-01-25 00:17:29'),(96,'Credit Card','Rep scler staphyloma NEC',NULL,NULL,'2022-08-07 09:20:31'),(97,'Netbanking','Flexible sigmoidoscopy',NULL,NULL,'2022-09-25 08:30:49'),(98,'Netbanking','Abdominal vein incision',NULL,NULL,'2023-01-19 01:42:30'),(99,'Debit Card','Thyroid vessel ligation',NULL,NULL,'2022-07-22 19:15:39'),(100,'COD','Oth unilat oophorectomy',NULL,NULL,'2022-04-10 05:46:47');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) NOT NULL,
  `category_id` int DEFAULT NULL,
  `product_price` int DEFAULT '0',
  `retailer_id` int DEFAULT NULL,
  `details` varchar(200) NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `fk_category_id` (`category_id`),
  KEY `retailer_id` (`retailer_id`),
  CONSTRAINT `fk_category_id` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`retailer_id`) REFERENCES `retailer` (`retailer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Wine - Sauvignon Blanc Oyster',NULL,3493,NULL,'Insert intercostal cath'),(2,'Beets - Mini Golden',NULL,8371,NULL,'Resection of nose'),(3,'Ice Cream Bar - Rolo Cone',NULL,6310,NULL,'Duodenal incision'),(4,'Corn - Cream, Canned',NULL,71,NULL,'Nephrocystanastomosi NOS'),(5,'Lime Cordial - Roses',NULL,6873,NULL,'Gastric freezing'),(6,'Beef - Ox Tail, Frozen',NULL,4619,NULL,'Salpingo-salpingostomy'),(7,'Coffee Cup 8oz 5338cd',NULL,2079,NULL,'Remov cystostomy tube'),(8,'Ham - Black Forest',NULL,8287,NULL,'Other patellar incision'),(9,'Pail - 4l White, With Handle',NULL,7980,NULL,'Therapeut evac ant chamb'),(10,'Chicken - Whole Roasting',NULL,2472,NULL,'Gracilis musc transplan'),(11,'Veal - Insides, Grains',NULL,8298,NULL,'Stretching of foreskin'),(12,'Sea Bass - Whole',NULL,3698,NULL,'External ear incis NEC'),(13,'Pepper - Scotch Bonnet',NULL,1393,NULL,'Total unilat salpingect'),(14,'Lettuce - Sea / Sea Asparagus',NULL,485,NULL,'Applic ext fix dev NEC'),(15,'Olives - Morracan Dired',NULL,1180,NULL,'Exc les tend sheath hand'),(16,'Wine - Puligny Montrachet A.',NULL,8962,NULL,'Spinal struct repair NEC'),(17,'Tart - Lemon',NULL,8963,NULL,'Plast op hand w grft NEC'),(18,'Tequila - Sauza Silver',NULL,6511,NULL,'Unilat ing hern rep NOS'),(19,'Seabream Whole Farmed',NULL,9901,NULL,'Open reduc-dislocat NEC'),(20,'Quail - Eggs, Fresh',NULL,3510,NULL,'Upper GI series'),(21,'Mushroom - Chanterelle Frozen',NULL,7911,NULL,'DIEP flap, free'),(22,'Onions - Cooking',NULL,567,NULL,'Parathyroid biopsy'),(23,'Fond - Neutral',NULL,3737,NULL,'Nephrotomy'),(24,'Wine - Cave Springs Dry Riesling',NULL,8008,NULL,'Pancreatic tube irrigat'),(25,'Wine - Red, Concha Y Toro',NULL,9598,NULL,'Eyebal/orbit dx proc NEC'),(26,'Chilli Paste, Hot Sambal Oelek',NULL,7101,NULL,'Remov breast tissu expan'),(27,'Steam Pan Full Lid',NULL,2989,NULL,'Oth perc proc bil trct'),(28,'Poppy Seed',NULL,9074,NULL,'Op bi dr/in ig hr-gr NEC'),(29,'Onions - Green',NULL,4234,NULL,'Metacarp/carp sequestrec'),(30,'Ecolab - Hand Soap Form Antibac',NULL,317,NULL,'C & s-lower resp'),(31,'Veal - Loin',NULL,8929,NULL,'C & s-peritoneum'),(32,'Buffalo - Short Rib Fresh',NULL,8080,NULL,'Excise lg intestine les'),(33,'Steel Wool S.o.s',NULL,4995,NULL,'Gb-to-intestine anastom'),(34,'Bread - Multigrain Oval',NULL,9825,NULL,'Vaginal repair NEC'),(35,'Sansho Powder',NULL,3829,NULL,'Lid reconst-ful thic NEC'),(36,'Scallop - St. Jaques',NULL,3301,NULL,'Lid reconstruction NOS'),(37,'Tomatoes - Cherry, Yellow',NULL,6417,NULL,'Remov trunk packing NEC'),(38,'Pastry - Cheese Baked Scones',NULL,9495,NULL,'Stapes mobilization'),(39,'Sugar - Brown',NULL,8092,NULL,'Opn mul seg lg intes NEC'),(40,'Glaze - Apricot',NULL,6858,NULL,'Other tenoplasty of hand'),(41,'Apricots - Halves',NULL,8697,NULL,'Closed adrenal gland bx'),(42,'Table Cloth 53x53 White',NULL,527,NULL,'Replace wound pack/drain'),(43,'Blouse / Shirt / Sweater',NULL,7281,NULL,'Repair of vessel NEC'),(44,'Allspice - Jamaican',NULL,2704,NULL,'Augment mammoplasty NOS'),(45,'Pastry - Banana Tea Loaf',NULL,9185,NULL,'Pancreat transplant NOS'),(46,'Cheese - Manchego, Spanish',NULL,9933,NULL,'Prostatic massage'),(47,'Mix - Cappucino Cocktail',NULL,2882,NULL,'Audiological evaluation'),(48,'Cheese - Grana Padano',NULL,799,NULL,'Op red-int fix rad/ulna'),(49,'Mushroom - Shitake, Dry',NULL,5861,NULL,'Cl fx reduc-toe'),(50,'Wheat - Soft Kernal Of Wheat',NULL,1450,NULL,'Thoracic tomography NEC'),(51,'Wine - Cave Springs Dry Riesling',NULL,4626,NULL,'Ovarian wedge resection'),(52,'Shrimp, Dried, Small / Lb',NULL,6685,NULL,'Unil femor hrn rep-grft'),(53,'Butter - Unsalted',NULL,6193,NULL,'Gum biopsy'),(54,'Champagne - Brights, Dry',NULL,8397,NULL,'Osteoclasis-femur'),(55,'Chilli Paste, Ginger Garlic',NULL,477,NULL,'Oth bunionect w sft corr'),(56,'Sauce - Balsamic Viniagrette',NULL,4655,NULL,'Construction ear auricle'),(57,'Spinach - Baby',NULL,8480,NULL,'Removal head/neck FB'),(58,'Coffee - Cafe Moreno',NULL,8296,NULL,'Perirectal tissue biopsy'),(59,'Sugar - Cubes',NULL,7609,NULL,'Lip biopsy'),(60,'Ketchup - Tomato',NULL,5765,NULL,'Contrast dacryocystogram'),(61,'Wine - Pinot Noir Stoneleigh',NULL,6854,NULL,'Surg induct labor NEC'),(62,'Saskatoon Berries - Frozen',NULL,5559,NULL,'Oth chest cage ostectomy'),(63,'Cheese - Comte',NULL,6059,NULL,'Remov imp dev-tib/fibula'),(64,'Veal - Leg',NULL,8059,NULL,'Dx proc fetus/amnion NEC'),(65,'Cloves - Whole',NULL,650,NULL,'Debrid open fx-humerus'),(66,'Browning Caramel Glace',NULL,976,NULL,'Suture of gum laceration'),(67,'Sauce - Alfredo',NULL,7651,NULL,'Intralum urete adhesioly'),(68,'Pears - Fiorelle',NULL,4128,NULL,'Diagnost vitreous aspir'),(69,'Pasta - Rotini, Colour, Dry',NULL,5108,NULL,'Adrenal lesion excision'),(70,'Cheese - Pied De Vents',NULL,1159,NULL,'Nasal sinus transillumin'),(71,'Gloves - Goldtouch Disposable',NULL,531,NULL,'Spine tract w skull dev'),(72,'Compound - Passion Fruit',NULL,1071,NULL,'Reopen laminectomy site'),(73,'Doilies - 5, Paper',NULL,1184,NULL,'Subarach-ureteral shunt'),(74,'Wine - White, Ej',NULL,2113,NULL,'Hymenectomy'),(75,'Pastry - Apple Muffins - Mini',NULL,6563,NULL,'Part thyroidectomy NEC'),(76,'Compound - Raspberry',NULL,7784,NULL,'Anoscopy'),(77,'Potatoes - Fingerling 4 Oz',NULL,2657,NULL,'Osteoclasis-radius/ulna'),(78,'Nut - Cashews, Whole, Raw',NULL,1508,NULL,'Skin repair & plasty NEC'),(79,'Wiberg Cure',NULL,6670,NULL,'Unil femor hrn rep-grft'),(80,'Tandoori Curry Paste',NULL,8655,NULL,'Cystoscopy NEC'),(81,'Dates',NULL,2968,NULL,'Applic ext fix dev NOS'),(82,'Truffle Shells - Semi - Sweet',NULL,1377,NULL,'Remov ext immobilization'),(83,'Basil - Seedlings Cookstown',NULL,3271,NULL,'Opn abltn renal les/tiss'),(84,'Cake - Mini Potato Pancake',NULL,7170,NULL,'Repair of spleen'),(85,'Jam - Apricot',NULL,4755,NULL,'Speech defect training'),(86,'Cookies - Englishbay Oatmeal',NULL,4769,NULL,'Suprapubic prostatectomy'),(87,'Ecolab - Solid Fusion',NULL,7788,NULL,'Periprostatic excision'),(88,'Fond - Neutral',NULL,930,NULL,'Brain/skull contrst xray'),(89,'Liqueur - Melon',NULL,202,NULL,'Lid reconstr w graft NEC'),(90,'Grenadine',NULL,1519,NULL,'Other transanal enema'),(91,'Bread - Granary Small Pull',NULL,8053,NULL,'Refus lmb/lmbsac pst/pst'),(92,'Cookie Dough - Oatmeal Rasin',NULL,8878,NULL,'Remov thoracotomy tube'),(93,'Carrots - Purple, Organic',NULL,5079,NULL,'Operation on eyeball NEC'),(94,'Trout - Hot Smkd, Dbl Fillet',NULL,4472,NULL,'Dx ultrasound-thorax NEC'),(95,'Cleaner - Comet',NULL,7255,NULL,'Toxicology-op wound'),(96,'Tea - Jasmin Green',NULL,1900,NULL,'Simp exc lymph struc NEC'),(97,'Pastry - Cherry Danish - Mini',NULL,3645,NULL,'Salpingotomy'),(98,'Wine - Pinot Noir Pond Haddock',NULL,263,NULL,'Reopen laminectomy site'),(99,'Mushroom - Morel Frozen',NULL,6156,NULL,'Splenotomy'),(100,'Lid Tray - 16in Dome',NULL,324,NULL,'Scleral operation NEC');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productfeedback`
--

DROP TABLE IF EXISTS `productfeedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productfeedback` (
  `product_feedback_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int DEFAULT NULL,
  `product_name` varchar(100) NOT NULL,
  `customer_id` int DEFAULT NULL,
  `review` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`product_feedback_id`),
  KEY `fk_product_id` (`product_id`),
  CONSTRAINT `fk_product_id` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productfeedback`
--

LOCK TABLES `productfeedback` WRITE;
/*!40000 ALTER TABLE `productfeedback` DISABLE KEYS */;
INSERT INTO `productfeedback` VALUES (1,NULL,'Cheese - Brick With Pepper',NULL,'Peripheral nerve suture'),(2,NULL,'Pimento - Canned',NULL,'Electroencephalogram'),(3,NULL,'Chocolate Bar - Reese Pieces',NULL,'Comb alcohol/drug rehab'),(4,NULL,'Bread - Onion Focaccia',NULL,'Cont inv mec ven 96+ hrs'),(5,NULL,'Buttons',NULL,'Vesic fistula repair NEC'),(6,NULL,'Wine - Magnotta - Belpaese',NULL,'Other phototherapy'),(7,NULL,'Corn Shoots',NULL,'Coronary bld flow monit'),(8,NULL,'Lemon Tarts',NULL,'Colostomy NOS'),(9,NULL,'Salmon - Atlantic, Fresh, Whole',NULL,'Circumcision'),(10,NULL,'Nestea - Iced Tea',NULL,'Bone graft to patella'),(11,NULL,'Truffle - Peelings',NULL,'Transfusion NEC'),(12,NULL,'Nori Sea Weed - Gold Label',NULL,'Repair of uvula'),(13,NULL,'Cake - French Pear Tart',NULL,'Pancreat sphincterotom'),(14,NULL,'Cheese Cheddar Processed',NULL,'Toxicology-lower urinary'),(15,NULL,'Bread - Roll, Soft White Round',NULL,'Wound irrigation NEC'),(16,NULL,'Grapes - Red',NULL,'Injection into pericard'),(17,NULL,'Uniform Linen Charge',NULL,'Electroencephalogram'),(18,NULL,'Veal - Provimi Inside',NULL,'Part ostect-radius/ulna'),(19,NULL,'Pasta - Rotini, Dry',NULL,'Abltn renal les/tiss NEC'),(20,NULL,'Bread - Pita',NULL,'Refusion of spine NEC'),(21,NULL,'Crackers - Soda / Saltins',NULL,'Digestive tract xray NEC'),(22,NULL,'Water - Green Tea Refresher',NULL,'Open robotic assist proc'),(23,NULL,'Thyme - Fresh',NULL,'Breast injection'),(24,NULL,'Ice Cream - Life Savers',NULL,'Tot cor transpos grt ves'),(25,NULL,'Bread Base - Gold Formel',NULL,'Ins/repl facet replc dev'),(26,NULL,'Mix - Cocktail Strawberry Daiquiri',NULL,'Bilat part salpingec NOS'),(27,NULL,'Coconut - Whole',NULL,'Aspir soft tiss hand NEC'),(28,NULL,'Pastry - Banana Tea Loaf',NULL,'Endosc destr pancrea les'),(29,NULL,'Tuna - Sushi Grade',NULL,'Brain meninge repair NEC'),(30,NULL,'Beef - Tender Tips',NULL,'Lacrimal sac incision'),(31,NULL,'Salami - Genova',NULL,'Perc ins intracran stent'),(32,NULL,'Tart Shells - Savory, 3',NULL,'Contrast arteriogram NEC'),(33,NULL,'Cookies - Amaretto',NULL,'Destroy fallop tube les'),(34,NULL,'Soup - Campbells Beef Noodle',NULL,'Dorsal/lat slit prepuce'),(35,NULL,'Muffin Mix - Raisin Bran',NULL,'Total hip replacement'),(36,NULL,'Sobe - Orange Carrot',NULL,'Reopen thyroid field wnd'),(37,NULL,'Browning Caramel Glace',NULL,'Osteoclasis NEC'),(38,NULL,'Muffins - Assorted',NULL,'Bile duct anastomos NEC'),(39,NULL,'Oil - Cooking Spray',NULL,'Opn thorc diaph hern NEC'),(40,NULL,'Island Oasis - Raspberry',NULL,'Reattach amputated ear'),(41,NULL,'Butcher Twine 4r',NULL,'Fat graft to breast'),(42,NULL,'Cleaner - Pine Sol',NULL,'Cl reduc disloc-hip'),(43,NULL,'Star Fruit',NULL,'Cell blk/pap-female gen'),(44,NULL,'Pasta - Fett Alfredo, Single Serve',NULL,'Anal biopsy'),(45,NULL,'Pur Source',NULL,'Left heart cardiac cath'),(46,NULL,'Cape Capensis - Fillet',NULL,'Post nasal pac for epist'),(47,NULL,'Magnotta - Bel Paese White',NULL,'Repl/rep oth tot hrt sys'),(48,NULL,'Wine - Taylors Reserve',NULL,'Repl cardiodefib genratr'),(49,NULL,'Beef Dry Aged Tenderloin Aaa',NULL,'Exc les soft tissue NEC'),(50,NULL,'Kale - Red',NULL,'Insert/repl oth neurost'),(51,NULL,'Scampi Tail',NULL,'Unilat simple mastectomy'),(52,NULL,'Macaroons - Two Bite Choc',NULL,'Neurectasis'),(53,NULL,'Pepper - Black, Whole',NULL,'Excis hand tend for grft'),(54,NULL,'Pineapple - Canned, Rings',NULL,'Conjunctival op NEC'),(55,NULL,'Mustard - Individual Pkg',NULL,'Remove penetrat FB eye'),(56,NULL,'Potatoes - Instant, Mashed',NULL,'Leg vein resect/anastom'),(57,NULL,'Potatoes - Mini Red',NULL,'Bone marrow ops NEC'),(58,NULL,'Flower - Commercial Spider',NULL,'Renal scan/isotope funct'),(59,NULL,'Remy Red',NULL,'Remove imp device-femur'),(60,NULL,'Salmon - Atlantic, Fresh, Whole',NULL,'Oth part ostectomy NOS'),(61,NULL,'Jam - Apricot',NULL,'Ocular thermography'),(62,NULL,'Jam - Raspberry',NULL,'Int fixation-tibia/fibul'),(63,NULL,'Ice Cream - Chocolate',NULL,'Scleral buckling NEC'),(64,NULL,'Creme De Banane - Marie',NULL,'Repl/rep thr unt tot hrt'),(65,NULL,'Cheese - Oka',NULL,'Metacarpophalangeal fus'),(66,NULL,'Pastry - Lemon Danish - Mini',NULL,'Repair oval/round window'),(67,NULL,'Compound - Pear',NULL,'Musculoskeletal op NEC'),(68,NULL,'Lamb Rack - Ontario',NULL,'P32 & eye tracer NEC'),(69,NULL,'Mushroom - Morels, Dry',NULL,'Tooth restorat by inlay'),(70,NULL,'Flour - Rye',NULL,'Rep vaginoent fistul NEC'),(71,NULL,'Wine - Chablis 2003 Champs',NULL,'Periprostatic incision'),(72,NULL,'Sausage - Andouille',NULL,'Gastric diagnos proc NEC'),(73,NULL,'Snails - Large Canned',NULL,'Revise knee replace NOS'),(74,NULL,'Cheese - Boursin, Garlic / Herbs',NULL,'Complete thyroidectomy'),(75,NULL,'Wine - Red, Pelee Island Merlot',NULL,'Perscr/fit/disp contacts'),(76,NULL,'Salmon - Atlantic, Skin On',NULL,'Bladder reconstruction'),(77,NULL,'Cookies - Englishbay Oatmeal',NULL,'Stretching of foreskin'),(78,NULL,'Juice - Orange',NULL,'Multisource radiosurgery'),(79,NULL,'Ham - Cooked',NULL,'Cell blk/pap-integument'),(80,NULL,'Chocolate - Dark',NULL,'Fasciotomy'),(81,NULL,'Coffee Cup 16oz Foam',NULL,'Perforat keratoplast NEC'),(82,NULL,'Beer - Fruli',NULL,'Heart vessel op NEC'),(83,NULL,'Melon - Cantaloupe',NULL,'Hrt revas byps anas NEC'),(84,NULL,'Chocolate - Feathers',NULL,'Ankle synovectomy'),(85,NULL,'Wine - Touraine Azay - Le - Rideau',NULL,'Cranial puncture NEC'),(86,NULL,'Wine - Chablis J Moreau Et Fils',NULL,'Hip structure division'),(87,NULL,'Soup - Campbells Chicken',NULL,'Patellar biopsy'),(88,NULL,'Silicone Parch. 16.3x24.3',NULL,'Vaginal const w grf/pros'),(89,NULL,'Table Cloth 120 Round White',NULL,'Closed gastric biopsy'),(90,NULL,'Juice Peach Nectar',NULL,'Lysis of tongue adhesion'),(91,NULL,'Lotus Rootlets - Canned',NULL,'Cataract extraction NEC'),(92,NULL,'Gin - Gilbeys London, Dry',NULL,'Choroid plexectomy'),(93,NULL,'Chocolate - Compound Coating',NULL,'Angiocardiography NOS'),(94,NULL,'Beets - Mini Golden',NULL,'Loc exc les metacar/car'),(95,NULL,'Chips Potato Salt Vinegar 43g',NULL,'Anal operation NEC'),(96,NULL,'Beef - Tenderloin',NULL,'Transfront pituitary bx'),(97,NULL,'Ostrich - Fan Fillet',NULL,'Tot repair tetral fallot'),(98,NULL,'Sour Puss Sour Apple',NULL,'Sclera reinforcement NEC'),(99,NULL,'Soup - Beef, Base Mix',NULL,'Lg bowel exteriorization'),(100,NULL,'Cheese - Grana Padano',NULL,'Pack ext auditory canal');
/*!40000 ALTER TABLE `productfeedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retailer`
--

DROP TABLE IF EXISTS `retailer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `retailer` (
  `retailer_id` int NOT NULL AUTO_INCREMENT,
  `Retailer_name` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  PRIMARY KEY (`retailer_id`),
  KEY `retailer_fk_product_id` (`product_id`),
  CONSTRAINT `retailer_fk_product_id` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retailer`
--

LOCK TABLES `retailer` WRITE;
/*!40000 ALTER TABLE `retailer` DISABLE KEYS */;
INSERT INTO `retailer` VALUES (1,'Schmeler Inc','Suite 34',NULL),(3,'Schowalter LLC','PO Box 77955',NULL),(4,'Ledner and Sons','PO Box 44932',NULL),(5,'Feil Inc','Apt 1758',NULL),(6,'Kreiger and Sons','Apt 262',NULL),(9,'Reichert-Ankunding','Room 370',NULL),(10,'Ratke-Reichel','PO Box 27853',NULL),(11,'Tillman-Feest','Apt 158',NULL),(12,'Zieme Inc','Apt 1880',NULL),(14,'Schneider and Sons','Suite 41',NULL),(16,'Heathcote-Steuber','Suite 91',NULL),(17,'Turner-Mertz','Suite 23',NULL),(19,'O\'Connell Group','Apt 163',NULL),(22,'Kreiger Group','Suite 97',NULL),(24,'Streich LLC','15th Floor',NULL),(25,'Douglas-Bogisich','Apt 296',NULL),(26,'Barton-Bogan','Suite 81',NULL),(27,'Baumbach-Brekke','18th Floor',NULL),(28,'Waters-Daniel','Apt 876',NULL),(29,'Conn LLC','PO Box 64360',NULL),(30,'Moore-Koelpin','Suite 74',NULL),(31,'Gutkowski Group','Apt 739',NULL),(32,'Sawayn and Sons','Apt 96',NULL),(33,'Wilderman LLC','6th Floor',NULL),(34,'MacGyver-Hayes','Apt 46',NULL),(35,'Gusikowski Inc','2nd Floor',NULL),(36,'Flatley and Sons','Suite 16',NULL),(38,'Gerhold Group','PO Box 32782',NULL),(39,'Goodwin LLC','Room 452',NULL),(40,'Kuvalis-Kunde','PO Box 94818',NULL),(44,'Walter Group','PO Box 2167',NULL),(46,'Boyer-Vandervort','PO Box 16488',NULL),(48,'Davis LLC','PO Box 74185',NULL),(49,'Baumbach-Keebler','Suite 5',NULL),(54,'Berge-Wehner','Suite 94',NULL),(55,'Emmerich Inc','Apt 1073',NULL),(56,'Erdman-Armstrong','Room 1820',NULL),(57,'Effertz Inc','PO Box 43114',NULL),(59,'Shields-Lemke','Suite 71',NULL),(60,'Blanda and Sons','Suite 53',NULL),(61,'Grimes-Sanford','Suite 17',NULL),(64,'Howe-Huels','PO Box 58301',NULL),(65,'Block LLC','Suite 64',NULL),(66,'Rogahn Inc','Suite 63',NULL),(67,'Halvorson and Sons','15th Floor',NULL),(69,'Kshlerin-Stoltenberg','Suite 11',NULL),(71,'Fahey-Hintz','Room 1081',NULL),(74,'Klocko Group','Room 359',NULL),(75,'Kertzmann LLC','5th Floor',NULL),(76,'Prohaska-Strosin','Apt 982',NULL),(77,'Quigley LLC','PO Box 10772',NULL),(78,'Kihn Inc','Apt 1390',NULL),(80,'Greenfelder and Sons','Suite 93',NULL),(81,'Rodriguez and Sons','Apt 1673',NULL),(82,'Spinka Group','Apt 716',NULL),(83,'Labadie LLC','PO Box 95237',NULL),(84,'Hyatt Inc','Room 1729',NULL),(85,'Thompson and Sons','4th Floor',NULL),(86,'Gutmann-Larson','Apt 1469',NULL),(87,'Jacobs-Senger','Apt 1410',NULL),(88,'Emmerich-Keeling','Apt 100',NULL),(89,'Upton Inc','PO Box 65490',NULL),(93,'Gutkowski Group','PO Box 56973',NULL),(94,'Windler-Cruickshank','3rd Floor',NULL),(95,'McGlynn LLC','PO Box 22104',NULL),(96,'Roberts Inc','Apt 1318',NULL),(97,'Rippin-Feil','Suite 49',NULL),(98,'Gutmann-Mann','Apt 1954',NULL),(99,'Schinner-Becker','PO Box 34460',NULL),(100,'Haley-Zieme','Room 321',NULL);
/*!40000 ALTER TABLE `retailer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-10 23:04:52
